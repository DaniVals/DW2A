<?php
	echo 'La fecha del servidor es: <br />';
	sleep(10);
	echo date(DATE_RFC822);
?>
